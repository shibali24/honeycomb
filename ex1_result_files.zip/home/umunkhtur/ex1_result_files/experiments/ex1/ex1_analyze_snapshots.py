#!/usr/bin/env python3
import argparse, json
from datetime import datetime


def parse_iso_z(s):
    """
    Parse an ISO 8601 string with nanosecond precision by truncating it to microseconds.
    """
    # If there are more than 6 digits in the fractional part, truncate to 6
    if '.' in s:
        parts = s.split('.')
        if len(parts[1]) > 6:
            s = parts[0] + '.' + parts[1][:6]  # Truncate to 6 digits
    # Replace 'Z' with '+00:00' for UTC timezone
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)

def ring_order(nodes):
    """
    nodes: dict ip -> state dict with keys id,url,successors,predecessor,finger
    returns: list of (id_int, id_str, url_str)
    """
    arr = []
    for st in nodes.values():
        arr.append((int(st["id"]), str(st["id"]), str(st["url"])))
    arr.sort(key=lambda x: x[0])
    return arr

def normalize_succ_list(L):
    return [(str(a), str(b)) for (a, b) in (L or [])]

def expected_first_successor(order, my_id_int, my_id_str, my_url):
    """
    Returns expected first successor (id_str, url_str) in the stable ring
    formed by the nodes present in 'order'.
    For n==1, expected successor is self.
    """
    n = len(order)
    if n == 0:
        return None
    if n == 1:
        return (my_id_str, my_url)

    # find index of self (match by both id and url for safety)
    idx = next(i for i, (iid, _, url) in enumerate(order) if iid == my_id_int and url == my_url)
    (_, sid, url) = order[(idx + 1) % n]
    return (sid, url)

def obs_first_successor_ok(order, st):
    """
    st: state dict for a node
    Returns True iff observed first successor matches expected first successor.
    """
    my_id_int = int(st["id"])
    my_id_str = str(st["id"])
    my_url    = str(st["url"])

    exp = expected_first_successor(order, my_id_int, my_id_str, my_url)
    obs_succ = normalize_succ_list(st.get("successors"))

    # If ring size 1, accept either "self" or empty successor list as OK
    if len(order) == 1:
        if len(obs_succ) == 0:
            return True
        return obs_succ[0] == exp

    if exp is None:
        return False
    if len(obs_succ) == 0:
        return False
    return obs_succ[0] == exp

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshots", required=True, help="jsonl from ex1_poll_snapshots.py")
    ap.add_argument("--expected_alive", type=int, default=0,
                    help="If >0, require this many nodes responding to evaluate correctness (prevents missing nodes from faking success).")
    ap.add_argument("--alive_slack", type=int, default=0,
                    help="Allow expected_alive - alive_slack responses (handles occasional timeouts).")
    ap.add_argument("--majority_frac", type=float, default=0.80,
                    help="Fraction of alive nodes that must have correct FIRST successor to count as reformed.")
    ap.add_argument("--consecutive", type=int, default=2,
                    help="Require this many consecutive SNAPs meeting the criterion (stability guard).")
    ap.add_argument("--out_json", default="", help="Optional summary json output")
    args = ap.parse_args()

    # load records
    recs = []
    with open(args.snapshots, "r") as f:
        for ln in f:
            ln = ln.strip()
            if ln:
                recs.append(json.loads(ln))
    if not recs:
        raise SystemExit("No snapshots found.")

    # pkill = MARK KILL_T0 if present else first SNAP time
    pkill = None
    for r in recs:
        if r.get("type") == "MARK" and r.get("mark") == "KILL_T0":
            pkill = parse_iso_z(r["t"])
            break
    if pkill is None:
        first_snap = next(r for r in recs if r.get("type") == "SNAP")
        pkill = parse_iso_z(first_snap["t"])

    # infer expected_alive if not provided: max alive seen in any SNAP
    max_alive = 0
    for r in recs:
        if r.get("type") != "SNAP":
            continue
        alive = sum(1 for v in r["nodes"].values() if v.get("ok"))
        max_alive = max(max_alive, alive)

    expected_alive = args.expected_alive if args.expected_alive > 0 else max_alive
    min_alive = max(1, expected_alive - args.alive_slack)

    precovery_ts = None
    precovery_dt_sec = None
    precovery_alive = None
    precovery_correct = None
    precovery_frac = None

    consec = 0
    first_hit_ts = None
    first_hit_stats = None  # (alive, correct, frac)

    for r in recs:
        if r.get("type") != "SNAP":
            continue

        ts = parse_iso_z(r["t"])
        dt_sec = (ts - pkill).total_seconds()

        # alive states
        alive_states = {}
        for ip, v in r["nodes"].items():
            if v.get("ok"):
                alive_states[ip] = v["state"]

        alive_n = len(alive_states)
        if alive_n < min_alive:
            # insufficient coverage → reset stability streak
            consec = 0
            first_hit_ts = None
            first_hit_stats = None
            continue

        order = ring_order(alive_states)

        # count how many nodes have correct *first successor*
        correct = 0
        for st in alive_states.values():
            if obs_first_successor_ok(order, st):
                correct += 1

        frac = (correct / alive_n) if alive_n > 0 else 0.0
        ok = (frac >= args.majority_frac)

        if ok:
            if consec == 0:
                first_hit_ts = ts
                first_hit_stats = (alive_n, correct, frac, dt_sec)
            consec += 1
        else:
            consec = 0
            first_hit_ts = None
            first_hit_stats = None

        if args.consecutive <= 1 and ok:
            # immediate acceptance: first snapshot meeting threshold
            precovery_ts = ts
            precovery_dt_sec = dt_sec
            precovery_alive = alive_n
            precovery_correct = correct
            precovery_frac = frac
            break

        if consec >= args.consecutive:
            # stability-confirmed: use the FIRST snapshot in the streak as "precovery"
            alive_n0, correct0, frac0, dt0 = first_hit_stats
            precovery_ts = first_hit_ts
            precovery_dt_sec = dt0
            precovery_alive = alive_n0
            precovery_correct = correct0
            precovery_frac = frac0
            break

    summary = {
        "pkill": pkill.isoformat(),
        "expected_alive": expected_alive,
        "min_alive_required": min_alive,
        "majority_frac": args.majority_frac,
        "consecutive_required": args.consecutive,

        "precovery": (precovery_ts.isoformat() if precovery_ts else None),
        "recovery_sec": precovery_dt_sec,

        "alive_at_precovery": precovery_alive,
        "correct_first_at_precovery": precovery_correct,
        "fraction_correct_first": precovery_frac,
    }

    print(json.dumps(summary, indent=2))

    if args.out_json:
        with open(args.out_json, "w") as f:
            json.dump(summary, f, indent=2)

if __name__ == "__main__":
    main()
