#!/usr/bin/env bash
set -euo pipefail

TRIALS="${TRIALS:-3}"
PORT="${PORT:-8735}"
ACTIVE_N="${ACTIVE_N:-70}"

# Where run_ex1_one_run.sh writes results
RUN_OUTDIR="${RUN_OUTDIR:-$HOME/ex1_results}"

# Skip if we already have results for that (F, trial, port)
SKIP_DONE="${SKIP_DONE:-1}"

# Optional: start trials at a later number (e.g., START_TRIAL=2)
START_TRIAL="${START_TRIAL:-1}"

# absolute nodes-to-kill targets (NOT percent)
if [[ -n "${F_VALUES_STR:-}" ]]; then
  read -r -a F_VALUES <<< "${F_VALUES_STR}"
else
  F_VALUES=(10 20)
fi

OUTDIR="${OUTDIR:-$HOME/ex1_sweeps}"
mkdir -p "$OUTDIR"
TS="$(date -u +"%Y%m%dT%H%M%SZ")"
SWEEP_LOG="$OUTDIR/ex1_sweep_${TS}_p${PORT}_n${ACTIVE_N}.log"
FAIL_LOG="$OUTDIR/ex1_sweep_${TS}_FAILURES.log"

log() {
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $*" | tee -a "$SWEEP_LOG"
}

# Convert absolute kill count F (nodes) -> percent argument for run_ex1_one_run.sh
pct_for_F() {
  local F="$1"
  python3 - <<PY
import math
F=int("$F")
N=int("$ACTIVE_N")
pct=math.ceil(100.0*F/float(N))
pct=max(1, min(99, pct))
print(pct)
PY
}

# Decide if this run is already done (based on the output naming pattern)
# run_ex1_one_run.sh outputs: $RUN_OUTDIR/ex1_f${F_PCT}_trial${t}_p${PORT}_*.{summary.csv,ring_correctness.json,...}
already_done() {
  local f_pct="$1"
  local trial="$2"
  local pattern="${RUN_OUTDIR}/ex1_f${f_pct}_trial${trial}_p${PORT}_*_summary.csv"
  compgen -G "$pattern" >/dev/null 2>&1
}

log "=== EX1 SWEEP START ==="
log "ACTIVE_N=$ACTIVE_N TRIALS=$TRIALS START_TRIAL=$START_TRIAL PORT=$PORT"
log "F_VALUES(nodes)=${F_VALUES[*]}"
log "RUN_OUTDIR=$RUN_OUTDIR (SKIP_DONE=$SKIP_DONE)"
log "Sweep log: $SWEEP_LOG"
log "Failures:  $FAIL_LOG"

for F in "${F_VALUES[@]}"; do
  F_PCT="$(pct_for_F "$F")"
  log "---- F(nodes)=$F -> using F_PCT=$F_PCT (based on ACTIVE_N=$ACTIVE_N) ----"

  for t in $(seq "$START_TRIAL" "$TRIALS"); do
    if [[ "$SKIP_DONE" == "1" ]] && already_done "$F_PCT" "$t"; then
      log "[SKIP] already have results for F_PCT=$F_PCT trial=$t port=$PORT (found summary.csv)"
      continue
    fi

    RUN_TAG="ex1_F${F}_trial${t}_n${ACTIVE_N}_p${PORT}_${TS}"

    log "=============================="
    log "RUN: $RUN_TAG"
    log "=============================="

    # Run one trial; continue on failure.
    set +e
    ACTIVE_N="$ACTIVE_N" PORT="$PORT" RUN_TAG="$RUN_TAG" DO_CLEANUP=0 \
      bash ./experiments/ex1/run_ex1_one_run.sh "$F_PCT" "$t"
    rc=$?
    set -e

    if [[ "$rc" -ne 0 ]]; then
      log "[FAIL] $RUN_TAG (exit=$rc) continuing..."
      echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] FAIL run_tag=$RUN_TAG F=$F F_PCT=$F_PCT trial=$t exit=$rc" >> "$FAIL_LOG"
    else
      log "[OK]   $RUN_TAG"
    fi
  done
done

log "=== EX1 SWEEP DONE ==="
log "Sweep log: $SWEEP_LOG"
log "Failures:  $FAIL_LOG"
