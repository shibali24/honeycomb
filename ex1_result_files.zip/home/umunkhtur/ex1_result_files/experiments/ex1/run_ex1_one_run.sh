#!/usr/bin/env bash
set -euo pipefail

# =========================
# EX1 ONE RUN (STABILIZE BEFORE KILL + PARTITIONS + SNAPSHOTS + RING-RECOVERY ANALYSIS)
#
# usage:
#   ACTIVE_N=70 ./experiments/ex1/run_ex1_one_run.sh <f_pct> <trial>
#
# Key fixes vs your previous version:
#   1) pkill (KILL_T0) is now written by THIS script at the real kill-end time,
#      NOT by the snapshot poller start time.
#   2) snapshot poller writes to a DATA file; we then concatenate MARKS+DATA
#      into the final *_snapshots.jsonl file that the analyzer reads.
#   3) analyzer invocation matches your CURRENT ex1_analyze_snapshots.py flags
#      (--majority_frac, --consecutive, --expected_alive, --alive_slack).
#   4) eligible-node extraction/filtering now supports snapshots where "nodes" is a dict
#      (your format: obj["nodes"][ip] = {"ok":..., "state":...}).
# =========================

# ---------- args ----------
F_PCT="${1:-10}"          # percent to kill (integer)
TRIAL="${2:-1}"

# ---------- config ----------
USERNAME="${USERNAME:-$(whoami)}"
KEY="${KEY:-$HOME/umunkhtur-keypair.pem}"
DIR="${DIR:-p4-final-ulemj_shibali_caroline}"

PORT="${PORT:-8749}"
ACTIVE_N="${ACTIVE_N:-40}"

# IMPORTANT: up to 10 minutes stabilization BEFORE kill
STABILIZE_SEC="${STABILIZE_SEC:-600}"
# check at 5 minutes
STABILIZE_CHECK_SEC="${STABILIZE_CHECK_SEC:-300}"

# Post-kill monitoring window (max)
POSTKILL_MAX_SEC="${POSTKILL_MAX_SEC:-600}"

POLL_SEC="${POLL_SEC:-1.0}"

# Soft convergence:
# partitions <= 1 AND largest component >= 0.80 * responding for N consecutive polls
SOFT_LARGEST_FRAC="${SOFT_LARGEST_FRAC:-0.80}"
SOFT_CONSEC="${SOFT_CONSEC:-5}"

# prune tiny partitions (<5) outside largest component (pre-kill)
PRUNE_SMALL_PARTITIONS_BELOW="${PRUNE_SMALL_PARTITIONS_BELOW:-5}"

# seed node
SEED_IP_DEFAULT="54.205.35.150"
SEED_IP="${SEED_IP:-$SEED_IP_DEFAULT}"

# Parallelism for RESET/CLEANUP stopping
STOP_PARALLEL="${STOP_PARALLEL:-20}"

# Correctness toggles
CORRECTNESS_MODE="${CORRECTNESS_MODE:-eligible}"      # eligible | expected
ELIGIBLE_CONSEC="${ELIGIBLE_CONSEC:-$SOFT_CONSEC}"    # K consecutive snapshot polls
ELIGIBLE_CUTOFF="${ELIGIBLE_CUTOFF:-converged}"       # converged | end

# Option B knobs (only used when CORRECTNESS_MODE=expected)
MIN_ALIVE_FRAC="${MIN_ALIVE_FRAC:-0.80}"              # e.g. 0.80
ALIVE_SLACK="${ALIVE_SLACK:-}"                        # if set, overrides MIN_ALIVE_FRAC-derived slack

# Ring recovery criteria (used by ex1_analyze_snapshots.py)
MAJORITY_FRAC="${MAJORITY_FRAC:-0.67}"
RING_CONSEC="${RING_CONSEC:-3}"

# Cleanup knob
DO_CLEANUP="${DO_CLEANUP:-1}"

SSH_OPTS="-i $KEY -o IdentitiesOnly=yes -o BatchMode=yes -o ConnectTimeout=7 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IPS_FILE="${IPS_FILE:-$SCRIPT_DIR/ips_all.txt}"

OUTDIR="${OUTDIR:-$HOME/ex1_results}"
mkdir -p "$OUTDIR"

TS="$(date -u +"%Y%m%dT%H%M%SZ")"
OUTBASE="$OUTDIR/ex1_f${F_PCT}_trial${TRIAL}_p${PORT}_${TS}"

RUN_LOG="${OUTBASE}_run.log"
TIMESERIES_CSV="${OUTBASE}_timeseries.csv"
SUMMARY_CSV="${OUTBASE}_summary.csv"
SSH_FAIL_TXT="${OUTBASE}_ssh_fail.txt"
KILLED_TXT="${OUTBASE}_killed.txt"
PRUNED_TXT="${OUTBASE}_pruned_small_partitions.txt"

# snapshots + analysis outputs
SNAP_JSONL="${OUTBASE}_snapshots.jsonl"                 # FINAL: marks+data
SNAP_MARKS_JSONL="${OUTBASE}_snapshots.marks.jsonl"     # marks only
SNAP_DATA_JSONL="${OUTBASE}_snapshots.data.jsonl"       # poller output only

SNAP_TAG="$(basename "$OUTBASE")"
LIVE_IPS_TXT="${OUTBASE}_live_ips_postkill.txt"

# eligible outputs
ELIGIBLE_IPS_TXT="${OUTBASE}_eligible_ips.txt"
SNAP_ELIGIBLE_JSONL="${OUTBASE}_snapshots.eligible.jsonl"
RING_JSON="${OUTBASE}_ring_correctness.json"

log() {
  local msg="$*"
  echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] $msg" | tee -a "$RUN_LOG"
}

die() {
  log "FATAL: $*"
  exit 1
}

# ---------- sanity ----------
[[ -f "$KEY" ]] || die "Key not found: $KEY"
[[ -f "$IPS_FILE" ]] || die "IPs file not found: $IPS_FILE"

# ---------- helpers ----------
stop_node() {
  local ip="$1"
  ssh $SSH_OPTS "$USERNAME@$ip" "
    cd ~/$DIR 2>/dev/null || exit 0
    PIDFILE=hb_pid_${PORT}.txt
    if [[ -f \$PIDFILE ]]; then
      PID=\$(cat \$PIDFILE 2>/dev/null || true)
      if [[ -n \"\$PID\" ]]; then kill \"\$PID\" 2>/dev/null || true; fi
      sleep 0.2
      if [[ -n \"\$PID\" ]]; then kill -9 \"\$PID\" 2>/dev/null || true; fi
      rm -f \$PIDFILE 2>/dev/null || true
    fi
    pkill -f \"python3.*node_ex1.py.*${PORT}\" 2>/dev/null || true
  " >/dev/null 2>&1 || true
}

stop_nodes_parallel() {
  local -a ips=("$@")
  (( ${#ips[@]} == 0 )) && return 0
  export -f stop_node
  export SSH_OPTS USERNAME DIR PORT
  printf "%s\n" "${ips[@]}" | xargs -n1 -P "$STOP_PARALLEL" -I{} bash -c 'stop_node "$@"' _ {}
}

start_node_seed() {
  local ip="$1"
  ssh $SSH_OPTS "$USERNAME@$ip" "
    set -e
    cd ~/$DIR
    : > hb_log_${PORT}.txt
    nohup python3 -u node_ex1.py $ip $PORT > hb_log_${PORT}.txt 2>&1 < /dev/null &
    echo \$! > hb_pid_${PORT}.txt
  " >/dev/null 2>&1 || return 1
}

start_node_joiner() {
  local ip="$1"
  local seed_ip="$2"
  ssh $SSH_OPTS "$USERNAME@$ip" "
    set -e
    cd ~/$DIR
    : > hb_log_${PORT}.txt
    nohup python3 -u node_ex1.py $ip $PORT $seed_ip $PORT > hb_log_${PORT}.txt 2>&1 < /dev/null &
    echo \$! > hb_pid_${PORT}.txt
  " >/dev/null 2>&1 || return 1
}

wait_seed_responsive() {
  local ip="$1"
  local deadline_sec="$2"
  python3 - <<PY
import time, sys, xmlrpc.client
IP="${ip}"
PORT=int("${PORT}")
DEADLINE=time.time()+float("${deadline_sec}")

class TimeoutTransport(xmlrpc.client.Transport):
    def __init__(self, timeout=2.0):
        super().__init__()
        self.timeout=timeout
    def make_connection(self, host):
        conn=super().make_connection(host)
        conn.timeout=self.timeout
        return conn

proxy=xmlrpc.client.ServerProxy(f"http://{IP}:{PORT}", transport=TimeoutTransport(2.0), allow_none=True)

while time.time() < DEADLINE:
    try:
        st = proxy.get_state()
        if st is not None:
            print("OK")
            sys.exit(0)
    except Exception:
        pass
    time.sleep(1.0)

print("TIMEOUT")
sys.exit(1)
PY
}

# partitions computed from successor0 edges among responding nodes
poll_partitions() {
  local live_ips_json="$1"
  python3 - <<PY
import json, xmlrpc.client
from collections import defaultdict, deque

LIVE_IPS = json.loads(r'''$live_ips_json''')
PORT = int("$PORT")

class TimeoutTransport(xmlrpc.client.Transport):
    def __init__(self, timeout=2.0):
        super().__init__()
        self.timeout = timeout
    def make_connection(self, host):
        conn = super().make_connection(host)
        conn.timeout = self.timeout
        return conn

def rpc(ip):
    return xmlrpc.client.ServerProxy(f"http://{ip}:{PORT}", transport=TimeoutTransport(2.0), allow_none=True)

def norm_pair(x):
    try:
        nid, url = x
        return str(nid), str(url)
    except Exception:
        return None

states = {}
responding = []
for ip in LIVE_IPS:
    try:
        st = rpc(ip).get_state()
        if isinstance(st, dict):
            states[ip] = st
            responding.append(ip)
    except Exception:
        pass

adj = defaultdict(set)
for ip, st in states.items():
    succs = st.get("successors") or st.get("succ") or []
    succ0 = None
    if isinstance(succs, list) and len(succs) > 0:
        p = norm_pair(succs[0])
        if p is not None:
            _, url = p
            succ_ip = url.split(":")[0]
            if succ_ip in states:
                succ0 = succ_ip
    _ = adj[ip]
    if succ0 is not None:
        adj[ip].add(succ0)
        adj[succ0].add(ip)

seen=set()
comps=[]
for ip in responding:
    if ip in seen: continue
    q=deque([ip]); seen.add(ip)
    comp=[ip]
    while q:
        u=q.popleft()
        for v in adj[u]:
            if v not in seen:
                seen.add(v); q.append(v); comp.append(v)
    comps.append(comp)

partitions=len(comps) if responding else 0
largest=max((len(c) for c in comps), default=0)
sizes=sorted([len(c) for c in comps], reverse=True)

print(f"{len(responding)} {partitions} {largest} " + ",".join(map(str,sizes)))
PY
}

poll_components_json() {
  local live_ips_json="$1"
  python3 - <<PY
import json, xmlrpc.client
from collections import defaultdict, deque

LIVE_IPS = json.loads(r'''$live_ips_json''')
PORT = int("$PORT")

class TimeoutTransport(xmlrpc.client.Transport):
    def __init__(self, timeout=2.0):
        super().__init__()
        self.timeout = timeout
    def make_connection(self, host):
        conn=super().make_connection(host)
        conn.timeout=self.timeout
        return conn

def rpc(ip):
    return xmlrpc.client.ServerProxy(f"http://{ip}:{PORT}", transport=TimeoutTransport(2.0), allow_none=True)

def norm_pair(x):
    try:
        nid, url = x
        return str(nid), str(url)
    except Exception:
        return None

states = {}
responding = []
for ip in LIVE_IPS:
    try:
        st = rpc(ip).get_state()
        if isinstance(st, dict):
            states[ip] = st
            responding.append(ip)
    except Exception:
        pass

adj = defaultdict(set)
for ip, st in states.items():
    succs = st.get("successors") or st.get("succ") or []
    succ0 = None
    if isinstance(succs, list) and len(succs) > 0:
        p = norm_pair(succs[0])
        if p is not None:
            _, url = p
            succ_ip = url.split(":")[0]
            if succ_ip in states:
                succ0 = succ_ip
    _ = adj[ip]
    if succ0 is not None:
        adj[ip].add(succ0)
        adj[succ0].add(ip)

seen=set()
comps=[]
for ip in responding:
    if ip in seen: continue
    q=deque([ip]); seen.add(ip)
    comp=[ip]
    while q:
        u=q.popleft()
        for v in adj[u]:
            if v not in seen:
                seen.add(v); q.append(v); comp.append(v)
    comps.append(sorted(comp))

comps_sorted = sorted(comps, key=lambda c: (-len(c), c[0] if c else ""))
out = {
    "responding": len(responding),
    "partitions": len(comps_sorted) if responding else 0,
    "largest": len(comps_sorted[0]) if comps_sorted else 0,
    "components": comps_sorted,
}
print(json.dumps(out))
PY
}

pick_fallback_seed() {
  local ip
  for ip in "${ACTIVE_IPS[@]}"; do
    if ssh $SSH_OPTS "$USERNAME@$ip" "echo ok" >/dev/null 2>&1; then
      echo "$ip"
      return 0
    fi
  done
  return 1
}

# ---------- load IPs ----------
mapfile -t ALL_IPS < <(grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}' "$IPS_FILE" | head -n 2000)
[[ "${#ALL_IPS[@]}" -gt 0 ]] || die "No IPs found in $IPS_FILE"

ACTIVE_IPS=("${ALL_IPS[@]:0:$ACTIVE_N}")

# ensure seed appears in active set (may be replaced later by fallback)
seed_found=0
for ip in "${ACTIVE_IPS[@]}"; do
  [[ "$ip" == "$SEED_IP" ]] && seed_found=1
done
if [[ "$seed_found" -eq 0 ]]; then
  ACTIVE_IPS[0]="$SEED_IP"
fi

: > "$SSH_FAIL_TXT"
: > "$KILLED_TXT"
: > "$PRUNED_TXT"
: > "$ELIGIBLE_IPS_TXT"

echo "t_epoch,kill_start_epoch,kill_end_epoch,t_rel_s,phase,responding,partitions,largest,comp_sizes" > "$TIMESERIES_CSV"
echo "trial,f_pct,active_n,launched,ssh_failed,stabilize_sec,killed,kill_start_epoch,kill_end_epoch,converged_t_rel_s,converged_epoch,final_partitions,final_largest,final_responding,correctness_mode,eligible_n" > "$SUMMARY_CSV"

log "=== EX1 ONE RUN (STABILIZE BEFORE KILL + PARTITIONS + SNAPSHOTS + ANALYZE) ==="
log "trial=$TRIAL f_pct=$F_PCT active_n=$ACTIVE_N port=$PORT seed=$SEED_IP"
log "stabilize_before_kill_sec=$STABILIZE_SEC (check_at=${STABILIZE_CHECK_SEC}s) postkill_max_sec=$POSTKILL_MAX_SEC poll_sec=$POLL_SEC"
log "soft converge: partitions<=1 AND largest>=${SOFT_LARGEST_FRAC}*responding for ${SOFT_CONSEC} polls"
log "prune: kill partitions outside largest with size < ${PRUNE_SMALL_PARTITIONS_BELOW}"
log "reset/cleanup parallelism: STOP_PARALLEL=$STOP_PARALLEL"
log "correctness: CORRECTNESS_MODE=$CORRECTNESS_MODE (ELIGIBLE_CONSEC=$ELIGIBLE_CONSEC cutoff=$ELIGIBLE_CUTOFF, MIN_ALIVE_FRAC=$MIN_ALIVE_FRAC ALIVE_SLACK=${ALIVE_SLACK:-unset})"
log "ring analyze: MAJORITY_FRAC=$MAJORITY_FRAC consecutive=$RING_CONSEC"
log "ips_file=$IPS_FILE"

SNAP_PID=""
CLEANUP_IPS=("${ACTIVE_IPS[@]}")   # will narrow after launch

cleanup() {
  if [[ "$DO_CLEANUP" != "1" ]]; then
    log "[CLEANUP] DO_CLEANUP=0 → skipping stop-on-exit."
    return 0
  fi

  log "[CLEANUP] stopping launched nodes..."
  if [[ -n "${SNAP_PID:-}" ]]; then
    kill "${SNAP_PID}" >/dev/null 2>&1 || true
    wait "${SNAP_PID}" >/dev/null 2>&1 || true
    SNAP_PID=""
  fi
  stop_nodes_parallel "${CLEANUP_IPS[@]}"
}
trap cleanup EXIT INT TERM

# ---------- reset ----------
log "[RESET] stopping any old processes..."
stop_nodes_parallel "${ACTIVE_IPS[@]}"

# ---------- start seed (with fallback) ----------
log "[START] seed on $SEED_IP"
if ! start_node_seed "$SEED_IP"; then
  log "[SEED] default seed $SEED_IP failed; picking fallback seed..."
  fallback="$(pick_fallback_seed || true)"
  [[ -n "${fallback:-}" ]] || die "No reachable seed candidates via SSH (all nodes unreachable)."
  SEED_IP="$fallback"
  ACTIVE_IPS[0]="$SEED_IP"
  log "[SEED] using fallback seed: $SEED_IP"
  start_node_seed "$SEED_IP" || die "Fallback seed $SEED_IP also failed to start."
fi

log "[SEED-WAIT] waiting for seed get_state() on ${SEED_IP}:${PORT} (max 90s)..."
if wait_seed_responsive "$SEED_IP" 90 >/dev/null; then
  log "[SEED-WAIT] seed responsive ✅"
else
  die "Seed ($SEED_IP) did not become responsive within 90s."
fi

# ---------- start joiners ----------
log "[START] joiners..."
LIVE_JOINED_IPS=("$SEED_IP")
for ip in "${ACTIVE_IPS[@]}"; do
  [[ "$ip" == "$SEED_IP" ]] && continue
  if start_node_joiner "$ip" "$SEED_IP"; then
    LIVE_JOINED_IPS+=("$ip")
  else
    log "[SKIP] $ip failed to start (ssh/command failure)."
    echo "$ip" >> "$SSH_FAIL_TXT"
  fi
done

LAUNCHED="${#LIVE_JOINED_IPS[@]}"
SSH_FAILED="$(wc -l < "$SSH_FAIL_TXT" | tr -d ' ')"
log "[START] launched=$LAUNCHED (including seed), ssh_failed=$SSH_FAILED"
(( LAUNCHED >= 5 )) || die "Too few nodes launched ($LAUNCHED)."

# from here on, cleanup only needs to consider actually launched nodes
CLEANUP_IPS=("${LIVE_JOINED_IPS[@]}")

# ---------- stabilize ----------
if (( STABILIZE_CHECK_SEC >= STABILIZE_SEC )); then
  STABILIZE_CHECK_SEC=$((STABILIZE_SEC/2))
fi

log "[STABILIZE] sleeping ${STABILIZE_CHECK_SEC}s..."
sleep "$STABILIZE_CHECK_SEC"

LIVE_IPS_JSON_JOINED="$(printf "%s\n" "${LIVE_JOINED_IPS[@]}" | python3 -c 'import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))')"
mid_out="$(poll_partitions "$LIVE_IPS_JSON_JOINED" || true)"
mid_resp="$(echo "$mid_out" | awk '{print $1}')"
mid_part="$(echo "$mid_out" | awk '{print $2}')"
mid_largest="$(echo "$mid_out" | awk '{print $3}')"
mid_sizes="$(echo "$mid_out" | awk '{print $4}')"

log "[STABILIZE-CHECK] t=${STABILIZE_CHECK_SEC}s responding=${mid_resp:-0} partitions=${mid_part:-0} largest=${mid_largest:-0} sizes=${mid_sizes:-}"

mid_good=0
if [[ -n "${mid_resp:-}" && "${mid_resp:-0}" -gt 0 ]]; then
  mid_good="$(python3 -c 'import sys,math
resp=int(sys.argv[1]); part=int(sys.argv[2]); largest=int(sys.argv[3]); frac=float(sys.argv[4])
ok = (part <= 1) and (largest >= math.ceil(frac*resp))
print(1 if ok else 0)' "${mid_resp:-0}" "${mid_part:-0}" "${mid_largest:-0}" "$SOFT_LARGEST_FRAC")"
fi

if [[ "$mid_good" == "1" ]]; then
  log "[STABILIZE] convergence satisfied at 5-min check → proceeding to kill now."
else
  remaining=$((STABILIZE_SEC - STABILIZE_CHECK_SEC))
  log "[STABILIZE] not converged at 5-min check → sleeping remaining ${remaining}s..."
  sleep "$remaining"
fi

# ---------- pre-kill snapshot ----------
LIVE_IPS_JSON_JOINED="$(printf "%s\n" "${LIVE_JOINED_IPS[@]}" | python3 -c 'import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))')"
pre_out="$(poll_partitions "$LIVE_IPS_JSON_JOINED" || true)"
pre_resp="$(echo "$pre_out" | awk '{print $1}')"
pre_part="$(echo "$pre_out" | awk '{print $2}')"
pre_largest="$(echo "$pre_out" | awk '{print $3}')"
pre_sizes="$(echo "$pre_out" | awk '{print $4}')"
now_epoch="$(date -u +%s)"
echo "${now_epoch},-1,-1,0,prekill,${pre_resp:-0},${pre_part:-0},${pre_largest:-0},${pre_sizes:-}" >> "$TIMESERIES_CSV"
log "[PREKILL] responding=${pre_resp:-0} partitions=${pre_part:-0} largest=${pre_largest:-0} sizes=${pre_sizes:-}"

# ---------- prune small partitions outside largest ----------
comp_json="$(poll_components_json "$LIVE_IPS_JSON_JOINED" || echo '{}')"

SMALL_OUTSIDE_JSON="$(python3 -c 'import json,sys
d=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
thr=int(sys.argv[2])
seed=sys.argv[3]
comps=d.get("components") or []
kill=[]
for c in comps[1:]:
    if len(c) < thr:
        for ip in c:
            if ip != seed:
                kill.append(ip)
print(json.dumps(kill))' "$comp_json" "$PRUNE_SMALL_PARTITIONS_BELOW" "$SEED_IP")"

mapfile -t PRUNE_LIST < <(python3 -c 'import json,sys; arr=json.loads(sys.stdin.read() or "[]"); print("\n".join(arr))' <<< "$SMALL_OUTSIDE_JSON")

if (( ${#PRUNE_LIST[@]} > 0 )); then
  log "[PRUNE] killing ${#PRUNE_LIST[@]} nodes in tiny partitions outside largest: ${PRUNE_LIST[*]}"
  for ip in "${PRUNE_LIST[@]}"; do
    echo "$ip" >> "$PRUNED_TXT"
  done
  stop_nodes_parallel "${PRUNE_LIST[@]}"
else
  log "[PRUNE] no tiny outside partitions to prune."
fi

# refresh largest partition list after pruning (best-effort)
LIVE_IPS_JSON_JOINED="$(printf "%s\n" "${LIVE_JOINED_IPS[@]}" | python3 -c 'import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))')"
comp_json2="$(poll_components_json "$LIVE_IPS_JSON_JOINED" || echo '{}')"

BIG_COMP_JSON="$(python3 -c 'import json,sys
d=json.loads(sys.argv[1]) if len(sys.argv)>1 else {}
comps=d.get("components") or []
big=comps[0] if comps else []
print(json.dumps(big))' "$comp_json2")"

mapfile -t BIG_COMP < <(python3 -c 'import json,sys; arr=json.loads(sys.stdin.read() or "[]"); print("\n".join(arr))' <<< "$BIG_COMP_JSON")
log "[PRUNE] largest component size now: ${#BIG_COMP[@]}"

# ---------- choose experiment kill set ONLY from largest partition ----------
KILL_COUNT=$(( (LAUNCHED * F_PCT + 99) / 100 ))
if (( KILL_COUNT >= LAUNCHED )); then KILL_COUNT=$((LAUNCHED-1)); fi
if (( KILL_COUNT < 1 )); then KILL_COUNT=1; fi

CANDIDATES=()
for ip in "${BIG_COMP[@]}"; do
  [[ "$ip" == "$SEED_IP" ]] && continue
  CANDIDATES+=("$ip")
done

if (( KILL_COUNT > ${#CANDIDATES[@]} )); then
  log "[KILL] NOTE: requested kill_count=$KILL_COUNT but largest-partition candidates=${#CANDIDATES[@]}; capping."
  KILL_COUNT="${#CANDIDATES[@]}"
fi
(( KILL_COUNT >= 1 )) || die "No candidates to kill in largest partition (seed-only?)."

mapfile -t TO_KILL < <(printf "%s\n" "${CANDIDATES[@]}" | shuf | head -n "$KILL_COUNT")

# ---------- REAL kill timestamps (HIGH-RES ISO + EPOCH) ----------
KILL_START_ISO="$(date -u +"%Y-%m-%dT%H:%M:%S.%NZ")"
KILL_START_EPOCH="$(date -u +%s)"

log "[KILL] killing $KILL_COUNT experiment nodes (all from largest partition): ${TO_KILL[*]}"
for ip in "${TO_KILL[@]}"; do
  echo "$ip" >> "$KILLED_TXT"
done

stop_nodes_parallel "${TO_KILL[@]}"

KILL_END_ISO="$(date -u +"%Y-%m-%dT%H:%M:%S.%NZ")"
KILL_END_EPOCH="$(date -u +%s)"

# build post-kill live set = largest component minus experiment kills
LIVE_IPS=()
for ip in "${BIG_COMP[@]}"; do
  skip=0
  for k in "${TO_KILL[@]}"; do
    [[ "$ip" == "$k" ]] && skip=1 && break
  done
  [[ "$skip" -eq 0 ]] && LIVE_IPS+=("$ip")
done

LIVE_IPS_JSON_POST="$(printf "%s\n" "${LIVE_IPS[@]}" | python3 -c 'import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))')"

deadline="$((KILL_END_EPOCH + POSTKILL_MAX_SEC))"
log "[POST] expected_remaining=${#LIVE_IPS[@]} monitoring up to ${POSTKILL_MAX_SEC}s..."

# ---------- snapshot poller ----------
printf "%s\n" "${LIVE_IPS[@]}" > "$LIVE_IPS_TXT"

# Marks file (we will later concatenate marks + data to produce SNAP_JSONL)
: > "$SNAP_MARKS_JSONL"
: > "$SNAP_DATA_JSONL"

python3 - <<PY >> "$SNAP_MARKS_JSONL"
import json
tag = r"""$SNAP_TAG"""
print(json.dumps({"type":"MARK","mark":"KILL_START","t":r"""$KILL_START_ISO""","tag":tag}))
print(json.dumps({"type":"MARK","mark":"KILL_T0","t":r"""$KILL_END_ISO""","tag":tag}))  # use kill-end as pkill baseline
PY

log "[SNAP] starting snapshot poll -> $SNAP_DATA_JSONL"
python3 -u "$SCRIPT_DIR/ex1_poll_snapshots.py" \
  --ips "$LIVE_IPS_TXT" \
  --port "$PORT" \
  --out "$SNAP_DATA_JSONL" \
  --seconds "$POSTKILL_MAX_SEC" \
  --interval "$POLL_SEC" \
  --tag "$SNAP_TAG" \
  >>"$RUN_LOG" 2>&1 &
SNAP_PID="$!"

# ---------- monitor post-kill (soft convergence) ----------
consec_good=0
converged_t_rel_s="-1"
converged_epoch="-1"

last_resp=0
last_part=0
last_largest=0
last_sizes=""

while true; do
  now_epoch="$(date -u +%s)"
  (( now_epoch < deadline )) || break

  out="$(poll_partitions "$LIVE_IPS_JSON_POST" || true)"
  resp="$(echo "$out" | awk '{print $1}')"
  part="$(echo "$out" | awk '{print $2}')"
  largest="$(echo "$out" | awk '{print $3}')"
  sizes="$(echo "$out" | awk '{print $4}')"

  resp="${resp:-0}"
  part="${part:-0}"
  largest="${largest:-0}"
  sizes="${sizes:-}"

  last_resp="$resp"
  last_part="$part"
  last_largest="$largest"
  last_sizes="$sizes"

  t_rel_s="$((now_epoch - KILL_END_EPOCH))"
  echo "${now_epoch},${KILL_START_EPOCH},${KILL_END_EPOCH},${t_rel_s},postkill,${resp},${part},${largest},${sizes}" >> "$TIMESERIES_CSV"

  good=0
  if (( resp > 0 )); then
    good="$(python3 -c 'import sys,math
resp=int(sys.argv[1]); part=int(sys.argv[2]); largest=int(sys.argv[3]); frac=float(sys.argv[4])
ok=(part<=1) and (largest>=math.ceil(frac*resp))
print(1 if ok else 0)' "$resp" "$part" "$largest" "$SOFT_LARGEST_FRAC")"
  fi

  if [[ "$good" == "1" ]]; then
    consec_good=$((consec_good + 1))
    if [[ "$converged_t_rel_s" == "-1" && "$consec_good" -ge "$SOFT_CONSEC" ]]; then
      converged_t_rel_s="$t_rel_s"
      converged_epoch="$now_epoch"
      log "[CONVERGED] converged_t_rel=${converged_t_rel_s}s (streak=${SOFT_CONSEC} polls) resp=${resp} part=${part} largest=${largest}"
      break
    fi
  else
    consec_good=0
  fi

  sleep "$POLL_SEC"
done

# stop snapshot polling early once converged / done
if [[ -n "${SNAP_PID:-}" ]]; then
  kill "${SNAP_PID}" >/dev/null 2>&1 || true
  wait "${SNAP_PID}" >/dev/null 2>&1 || true
  SNAP_PID=""
fi

# finalize snapshots file = MARKS + DATA (this is what analyzer reads)
cat "$SNAP_MARKS_JSONL" "$SNAP_DATA_JSONL" > "$SNAP_JSONL"
log "[SNAP] finalized snapshots -> $SNAP_JSONL (marks+data)"

# ---------- Option A: compute eligible responders + filter snapshots ----------
eligible_n=0
ANALYZE_INPUT="$SNAP_JSONL"
expected_alive_for_analyze="${#LIVE_IPS[@]}"
alive_slack_for_analyze=2

if [[ "$CORRECTNESS_MODE" == "eligible" ]]; then
  log "[ELIGIBLE] computing eligible nodes from snapshots (K=$ELIGIBLE_CONSEC, cutoff=$ELIGIBLE_CUTOFF)..."

  CUTOFF_EPOCH="-1"
  if [[ "$ELIGIBLE_CUTOFF" == "converged" && "$converged_epoch" != "-1" ]]; then
    CUTOFF_EPOCH="$converged_epoch"
  fi

  # Extract eligible = intersection of responders across last K snapshots (up to cutoff)
  python3 - <<PY > "$ELIGIBLE_IPS_TXT"
import json, sys

snap_path = r"""$SNAP_JSONL"""
K = int(r"""$ELIGIBLE_CONSEC""")
cutoff = int(r"""$CUTOFF_EPOCH""")

def responders_from_obj(obj):
    ips=set()

    # shape A: obj["nodes"] is dict: ip -> {"ok": bool, "state": dict, ...}
    nodes = obj.get("nodes")
    if isinstance(nodes, dict):
        for ip, r in nodes.items():
            if not ip:
                continue
            if isinstance(r, dict):
                ok = r.get("ok")
                st = r.get("state")
                if ok is True or isinstance(st, dict):
                    ips.add(str(ip))
        return ips

    # shape B: obj["results"][ip] = {...} or obj["responses"][ip] = {...}
    for key in ("results","responses"):
        d = obj.get(key)
        if isinstance(d, dict):
            for ip, r in d.items():
                if not ip:
                    continue
                if isinstance(r, dict):
                    ok = r.get("ok")
                    st = r.get("state")
                    if ok is True or isinstance(st, dict):
                        ips.add(str(ip))
                else:
                    ips.add(str(ip))
            return ips

    # shape C: obj["nodes"] is list of {"ip":..., "ok":..., "state":...}
    if isinstance(nodes, list):
        for r in nodes:
            if not isinstance(r, dict):
                continue
            ip = r.get("ip") or r.get("host")
            if not ip:
                continue
            ok = r.get("ok")
            st = r.get("state")
            if ok is True or isinstance(st, dict):
                ips.add(str(ip))
        return ips

    return ips

def get_epoch(obj):
    # best effort: some pollers include epoch fields; if not present we just won't cutoff
    for k in ("t_epoch","epoch","ts","time"):
        v=obj.get(k)
        if isinstance(v,(int,float,str)):
            try:
                return int(float(v))
            except Exception:
                pass
    return None

objs=[]
with open(snap_path,"r") as f:
    for line in f:
        line=line.strip()
        if not line:
            continue
        try:
            obj=json.loads(line)
        except Exception:
            continue
        if obj.get("type") != "SNAP":
            continue
        t=get_epoch(obj)
        if cutoff > 0 and t is not None and t > cutoff:
            break
        objs.append(obj)

window = objs[-K:] if len(objs) >= K else objs
if not window:
    sys.exit(0)

sets=[responders_from_obj(o) for o in window]
eligible=set.intersection(*sets) if sets else set()

for ip in sorted(eligible):
    print(ip)

sys.stderr.write(f"eligible_count={len(eligible)} window={len(window)} total_snaps={len(objs)} cutoff={cutoff}\\n")
PY

  eligible_n="$(wc -l < "$ELIGIBLE_IPS_TXT" | tr -d ' ')"
  log "[ELIGIBLE] eligible_n=$eligible_n (writing $ELIGIBLE_IPS_TXT)"

  if (( eligible_n > 0 )); then
    # Filter snapshot JSONL down to eligible nodes only (supports nodes=dict and results/responses)
    python3 - <<PY
import json

in_path=r"""$SNAP_JSONL"""
out_path=r"""$SNAP_ELIGIBLE_JSONL"""
eligible=set([l.strip() for l in open(r"""$ELIGIBLE_IPS_TXT""","r") if l.strip()])

def filter_obj(obj):
    # keep MARK lines as-is
    if obj.get("type") != "SNAP":
        return obj

    nodes=obj.get("nodes")

    # nodes as dict
    if isinstance(nodes, dict):
        obj["nodes"]={ip:v for ip,v in nodes.items() if str(ip) in eligible}
        return obj

    # results/responses as dict
    for key in ("results","responses"):
        d=obj.get(key)
        if isinstance(d, dict):
            obj[key]={ip:v for ip,v in d.items() if str(ip) in eligible}
            return obj

    # nodes as list
    if isinstance(nodes, list):
        obj["nodes"]=[r for r in nodes if isinstance(r,dict) and str(r.get("ip") or r.get("host") or "") in eligible]
    return obj

with open(in_path,"r") as fin, open(out_path,"w") as fout:
    for line in fin:
        line=line.strip()
        if not line:
            continue
        try:
            obj=json.loads(line)
        except Exception:
            continue
        obj=filter_obj(obj)
        fout.write(json.dumps(obj, separators=(",",":"))+"\n")
PY

    ANALYZE_INPUT="$SNAP_ELIGIBLE_JSONL"
    expected_alive_for_analyze="$eligible_n"
    alive_slack_for_analyze="${ALIVE_SLACK:-1}"
    log "[ELIGIBLE] filtered snapshots -> $SNAP_ELIGIBLE_JSONL (expected_alive=$expected_alive_for_analyze alive_slack=$alive_slack_for_analyze)"
  else
    log "[ELIGIBLE] WARNING: eligible_n=0, falling back to expected mode over full snapshots."
    CORRECTNESS_MODE="expected"
  fi
fi

# ---------- Option B: compute alive_slack from MIN_ALIVE_FRAC if needed ----------
if [[ "$CORRECTNESS_MODE" == "expected" ]]; then
  expected_alive_for_analyze="${#LIVE_IPS[@]}"

  if [[ -n "${ALIVE_SLACK:-}" ]]; then
    alive_slack_for_analyze="$ALIVE_SLACK"
  else
    alive_slack_for_analyze="$(python3 -c 'import math,sys
exp=int(sys.argv[1]); frac=float(sys.argv[2])
min_req=math.ceil(frac*exp)
slack=max(0, exp-min_req)
print(slack)' "$expected_alive_for_analyze" "$MIN_ALIVE_FRAC")"
  fi

  log "[EXPECTED] expected_alive=$expected_alive_for_analyze -> alive_slack=$alive_slack_for_analyze (min_alive≈ceil($MIN_ALIVE_FRAC*expected_alive))"
fi

# ---------- analyze snapshots (pkill -> precovery) ----------
if [[ -f "$ANALYZE_INPUT" ]]; then
  log "[ANALYZE] computing recovery -> $RING_JSON (input=$(basename "$ANALYZE_INPUT"))"
  python3 -u "$SCRIPT_DIR/ex1_analyze_snapshots.py" \
    --snapshots "$ANALYZE_INPUT" \
    --expected_alive "$expected_alive_for_analyze" \
    --alive_slack "$alive_slack_for_analyze" \
    --majority_frac "$MAJORITY_FRAC" \
    --consecutive "$RING_CONSEC" \
    --out_json "$RING_JSON" >>"$RUN_LOG" 2>&1 || log "[ANALYZE] WARNING: analyze failed"
else
  log "[ANALYZE] WARNING: snapshot file missing ($ANALYZE_INPUT); skipping analyze."
fi

# ---------- summary ----------
echo "${TRIAL},${F_PCT},${ACTIVE_N},${LAUNCHED},${SSH_FAILED},${STABILIZE_SEC},${KILL_COUNT},${KILL_START_EPOCH},${KILL_END_EPOCH},${converged_t_rel_s},${converged_epoch},${last_part},${last_largest},${last_resp},${CORRECTNESS_MODE},${eligible_n}" >> "$SUMMARY_CSV"

log "[DONE] wrote:"
log "  timeseries:     $TIMESERIES_CSV"
log "  summary:        $SUMMARY_CSV"
log "  ssh_fail:       $SSH_FAIL_TXT"
log "  killed(exp):    $KILLED_TXT"
log "  pruned(small):  $PRUNED_TXT"
log "  snapshots:      $SNAP_JSONL"
log "  snap_marks:     $SNAP_MARKS_JSONL"
log "  snap_data:      $SNAP_DATA_JSONL"
log "  eligible_ips:   $ELIGIBLE_IPS_TXT"
log "  ring_json:      $RING_JSON"
log "  live_ips:       $LIVE_IPS_TXT"
