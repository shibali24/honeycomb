#!/usr/bin/env python3
import argparse, json, time, socket
from datetime import datetime, timezone
import xmlrpc.client

RPC_TIMEOUT = 2.0

class TimeoutTransport(xmlrpc.client.Transport):
    def __init__(self, timeout):
        super().__init__()
        self.timeout = timeout
    def make_connection(self, host):
        conn = super().make_connection(host)
        conn.timeout = self.timeout
        return conn

def rpc_proxy(url):
    return xmlrpc.client.ServerProxy(
        "http://" + url,
        transport=TimeoutTransport(RPC_TIMEOUT),
        allow_none=True
    )

def utc_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ips", required=True, help="Path to file with one IP per line")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--out", required=True, help="Output .jsonl file")
    ap.add_argument("--seconds", type=float, default=60.0)
    ap.add_argument("--interval", type=float, default=0.5)
    ap.add_argument("--tag", default="", help="Optional run tag")
    ap.add_argument("--mark_kill", action="store_true",
                    help="Write a marker line at start (t0 for analysis)")
    args = ap.parse_args()

    with open(args.ips, "r") as f:
        ips = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]

    t_start = time.time()

    with open(args.out, "w") as out:
        if args.mark_kill:
            out.write(json.dumps({"type":"MARK", "mark":"KILL_T0", "t": utc_iso(), "tag": args.tag}) + "\n")

        while True:
            now = time.time()
            if now - t_start > args.seconds:
                break

            rec = {
                "type": "SNAP",
                "t": utc_iso(),
                "t_epoch": now,
                "tag": args.tag,
                "nodes": {}
            }

            for ip in ips:
                url = f"{ip}:{args.port}"
                try:
                    proxy = rpc_proxy(url)
                    st = proxy.get_state()
                    rec["nodes"][ip] = {"ok": True, "state": st}
                except (socket.timeout, ConnectionRefusedError) as e:
                    rec["nodes"][ip] = {"ok": False, "err": f"{type(e).__name__}"}
                except Exception as e:
                    rec["nodes"][ip] = {"ok": False, "err": f"{type(e).__name__}: {e}"}

            out.write(json.dumps(rec, separators=(",",":")) + "\n")
            out.flush()
            time.sleep(args.interval)

if __name__ == "__main__":
    main()
