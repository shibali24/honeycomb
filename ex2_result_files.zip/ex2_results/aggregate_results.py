import os
import json
import numpy as np
import matplotlib.pyplot as plt

# Function to aggregate trial results
def aggregate_trial_results():
    aggregated_results = {
        "accuracy_threshold": [],
        "f_killed": [],
        "frac_nodes_ge_threshold": [],
        "max_accuracy": [],
        "mean_accuracy": [],
        "median_accuracy": [],
        "min_accuracy": [],
        "n_active": [],
        "nodes_ge_threshold": [],
        "sent_count": [],
        "trial": [],
        "unreachable_nodes": [],
    }

    base_directory = os.getcwd()
    print(f"Current working directory: {base_directory}")
    
    for subdir, _, files in os.walk(base_directory):
        for filename in files:
            if filename.endswith(".json"):
                file_path = os.path.join(subdir, filename)
                if os.path.exists(file_path) and os.path.getsize(file_path) > 0:
                    with open(file_path, "r") as file:
                        try:
                            trial_data = json.load(file)
                            def safe_convert(value, dtype):
                                try:
                                    if value is not None:
                                        return dtype(value)
                                    else:
                                        return None
                                except (ValueError, TypeError) as e:
                                    print(f"Error converting value '{value}' to {dtype}: {e}")
                                    return None

                            aggregated_results["accuracy_threshold"].append(
                                safe_convert(trial_data.get("accuracy_threshold", None), float))
                            aggregated_results["f_killed"].append(
                                safe_convert(trial_data.get("f_killed", None), int))
                            aggregated_results["frac_nodes_ge_threshold"].append(
                                safe_convert(trial_data.get("frac_nodes_ge_threshold", None), float))
                            aggregated_results["max_accuracy"].append(
                                safe_convert(trial_data.get("max_accuracy", None), float))
                            aggregated_results["mean_accuracy"].append(
                                safe_convert(trial_data.get("mean_accuracy", None), float))
                            aggregated_results["median_accuracy"].append(
                                safe_convert(trial_data.get("median_accuracy", None), float))
                            aggregated_results["min_accuracy"].append(
                                safe_convert(trial_data.get("min_accuracy", None), float))
                            aggregated_results["n_active"].append(
                                safe_convert(trial_data.get("n_active", None), int))
                            aggregated_results["nodes_ge_threshold"].append(
                                safe_convert(trial_data.get("nodes_ge_threshold", None), int))
                            aggregated_results["sent_count"].append(
                                safe_convert(trial_data.get("sent_count", None), int))
                            aggregated_results["trial"].append(
                                safe_convert(trial_data.get("trial", None), int))
                            aggregated_results["unreachable_nodes"].append(
                                safe_convert(trial_data.get("unreachable_nodes", None), int))
                        except json.JSONDecodeError:
                            print(f"Error decoding JSON in file: {file_path}")
                            continue

    return aggregated_results

# Function to calculate mean, median, min, and max for the aggregated data
def calculate_aggregates(data):
    result = {}

    for key, values in data.items():
        values = [v for v in values if v is not None]
        print(f"Processing {key}: {values}")  # Debugging line to check the content of 'values'

        if all(isinstance(v, (int, float)) for v in values):
            if values:
                result[key] = {
                    "mean": np.mean(values) if len(values) > 0 else None,
                    "median": np.median(values) if len(values) > 0 else None,
                    "min": min(values) if len(values) > 0 else None,
                    "max": max(values) if len(values) > 0 else None,
                }
        else:
            print(f"Warning: {key} contains non-numeric values: {values}")

    return result

# Function to aggregate results based on f_killed (failure levels)
def aggregate_by_failure_level(aggregated_data):
    failure_levels = [5, 10, 15, 20]  # Defined failure levels
    
    aggregated_by_f = {}

    for f in failure_levels:
        print(f"Processing failure level: {f}")
        
        f_results = {
            "mean_accuracy": [],
            "median_accuracy": [],
            "min_accuracy": [],
        }
        
        for i, f_killed in enumerate(aggregated_data["f_killed"]):
            if f_killed == f:
                if aggregated_data["mean_accuracy"][i] is not None:
                    f_results["mean_accuracy"].append(aggregated_data["mean_accuracy"][i])
                if aggregated_data["median_accuracy"][i] is not None:
                    f_results["median_accuracy"].append(aggregated_data["median_accuracy"][i])
                if aggregated_data["min_accuracy"][i] is not None:
                    f_results["min_accuracy"].append(aggregated_data["min_accuracy"][i])

        if f_results["mean_accuracy"]:
            aggregated_by_f[f] = {
                "mean_accuracy": {
                    "mean": np.mean(f_results["mean_accuracy"]),
                    "median": np.median(f_results["mean_accuracy"]),
                    "min": min(f_results["mean_accuracy"]),
                    "max": max(f_results["mean_accuracy"]),
                },
                "median_accuracy": {
                    "mean": np.mean(f_results["median_accuracy"]),
                    "median": np.median(f_results["median_accuracy"]),
                    "min": min(f_results["median_accuracy"]),
                    "max": max(f_results["median_accuracy"]),
                },
                "min_accuracy": {
                    "mean": np.mean(f_results["min_accuracy"]),
                    "median": np.median(f_results["min_accuracy"]),
                    "min": min(f_results["min_accuracy"]),
                    "max": max(f_results["min_accuracy"]),
                }
            }
    
    return aggregated_by_f

# Function to plot the results by trial for each failure level
def plot_results_by_trial(aggregated_by_failure):
    failure_levels = [5, 10, 15, 20]  # Updated failure levels
    
    # Create a minimalistic plot
    plt.figure(figsize=(10, 8))

    for f in failure_levels:
        # Directly access the mean and median for the failure level
        mean_accuracy = aggregated_by_failure[f]["mean_accuracy"]["mean"]
        median_accuracy = aggregated_by_failure[f]["median_accuracy"]["mean"]

        # Plot Mean Accuracy vs Failure Level
        plt.subplot(2, 1, 1)
        plt.plot(f, mean_accuracy, marker='o', linestyle='-', color='b', label=f"Failure level {f}" if f == 5 else "")
        
        # Plot Median Accuracy vs Failure Level
        plt.subplot(2, 1, 2)
        plt.plot(f, median_accuracy, marker='x', linestyle='--', color='g', label=f"Failure level {f}" if f == 5 else "")

    # Customize the plots
    plt.subplot(2, 1, 1)
    plt.xlabel("Failure Level (f_killed)")
    plt.ylabel("Mean Accuracy")
    plt.title("Mean Accuracy vs Failure Level")
    plt.legend()

    plt.subplot(2, 1, 2)
    plt.xlabel("Failure Level (f_killed)")
    plt.ylabel("Median Accuracy")
    plt.title("Median Accuracy vs Failure Level")
    plt.legend()

    plt.tight_layout()

    # Save the plot as a PNG file in the same directory
    plt.savefig("message_delivery_by_trial_v2.png", dpi=300)
    plt.show()  # Optionally display the plot on the screen


# Main function to run the analysis and plotting
def main():
    # Step 1: Aggregate the data
    aggregated_data = aggregate_trial_results()

    # Step 2: Calculate the aggregates (mean, median, etc.)
    aggregated_statistics = calculate_aggregates(aggregated_data)

    # Step 3: Aggregate by failure level (f_killed)
    aggregated_by_failure = aggregate_by_failure_level(aggregated_data)

    # Step 4: Plot the results
    plot_results_by_trial(aggregated_by_failure)

# Run the main function
if __name__ == "__main__":
    main()
